"""Datastax Advanced Authentication Client Plugin for Cassandra Python Driver."""

__version__ = "1.0.0"

#
# Copyright DataStax, Inc.
#
# Please see the included license file for details.
#
import base64
import hashlib
import http.server
import json
import logging
import os
import secrets
import socket
import socketserver
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from enum import Enum
from threading import Lock

from cassandra.auth import Authenticator, AuthProvider, PlainTextAuthenticator

log = logging.getLogger(__name__)


class OIDCAuthFlows(Enum):
    CODE = "code"
    CLIENT = "client"


class AdvancedAuthProvider(AuthProvider):
    """
    An :class:`~.AuthProvider` that works with DataStax Hyper-Converged Database (HCD) and
    DataStax Enterprise 6.9 to authenticate using OIDC (OAuth 2.0).

    This auth provider is meant to be used with cqlsh only and supports both plain-text and
    OIDC authentication. It is not intended to be used with the DataStax Python driver directly
    as it performs OIDC authentication on behalf of the driver and prints out to stdout/stderr.

    Example of HCD ~/.cassandra/cqlshrc configuration ::

        [auth_provider]
        module = datastax_db_auth.auth
        classname = AdvancedAuthProvider
        issuer_url = https://localhost:8080/realms/db-testing
        client_id = my-client-id
        client_secret = my-client-secret
        truststore = /path/to/truststore.pem
        ssl_verify = true
        auth_flow = code
        callback_url = /oauth/callback
        callback_port = 0
        browser_auto_open = true

    Example of DSE 6.9 ~/.cassandra/cqlshrc configuration ::

        [oidc]
        issuer_url = https://localhost:8080/realms/db-testing
        client_id = my-client-id
        client_secret = my-client-secret
        truststore = /path/to/truststore.pem
        ssl_verify = true
        auth_flow = code
        callback_url = /oauth/callback
        callback_port = 0
        browser_auto_open = true

    When username/password are provided, it defaults to plain-text authentication. Otherwise,
    it uses OIDC authentication, using either Authorization Code flow with PKCE or Client
    Credentials flow, depending on the `auth_flow` parameter. The access token is then used to
    authenticate the user against the database and identify the user's roles and permissions.

    For OIDC authentication, it automatically:
    - Discovers OIDC endpoints via the standard .well-known/openid-configuration
    - Obtains and caches access tokens to minimize authentication overhead
    - Supports custom certificate authority (CA) certificates for secure connections
    """

    DEFAULT_EXPIRATION_TIME = 300
    REFRESH_FACTOR = 0.75  # 75% of the original expiration time

    def __init__(
        self,
        issuer_url=None,
        client_id=None,
        client_secret=None,
        username=None,
        password=None,
        truststore=None,
        ssl_verify=True,
        auth_flow=OIDCAuthFlows.CODE.value,
        callback_url="/oauth/callback",
        callback_port=0,
        browser_auto_open=True,
    ):
        """
        Initialize the advanced authentication provider.

        Args:
            issuer_url (str, optional): The OIDC provider URL (e.g., "https://auth.example.com/")
            client_id (str, optional): The OAuth client ID for client credentials flow
            client_secret (str, optional): The OAuth client secret (used for private/secure
                                           clients).
            username (str, optional): Username for plain-text authentication.
            password (str, optional): Password for plain-text authentication.
            truststore (str, optional): Path to a PEM-formatted certificate file for verifying
                                        the OIDC server's SSL certificate.
            ssl_verify (bool, optional): Whether to verify SSL certificates when connecting to
                                         the OIDC provider. Setting to False is insecure and should
                                         only be used in development. Defaults to True.
            auth_flow (str, optional): Set to 'code' for authorization code flow (default) or
                                       'client' for client credentials flow.
            callback_url (str, optional): The URL path for the OIDC callback endpoint when using
                                          authorization code flow. Defaults to "/oauth/callback".
            callback_port (int, optional): The local http port for the OIDC callback endpoint when
                                           using authorization code flow. Defaults to 0 (ephemeral
                                           port).
            browser_auto_open (bool, optional): Whether to automatically open the web browser when
                                                using authorization code flow. Defaults to True.
        """
        self.issuer_url = issuer_url
        self.client_id = client_id
        self.client_secret = client_secret
        if self.issuer_url:
            if not self.client_id:
                raise ValueError("client_id is required when issuer_url is provided.")

        self.username = username
        self.password = password

        # SSL configuration for HTTP requests
        self.truststore_file = truststore
        self._ssl_context = ssl.create_default_context()

        try:
            self.ssl_verify = self.to_bool(ssl_verify)
        except ValueError as ex:
            raise ValueError(f"Invalid value for ssl_verify: {ex}")

        if not auth_flow:
            auth_flow = OIDCAuthFlows.CODE.value
        try:
            self.auth_flow = OIDCAuthFlows(auth_flow)
        except ValueError:
            supported_flows = [member.value for member in OIDCAuthFlows]
            raise ValueError(
                f"Invalid value for auth_flow: '{auth_flow}'. Expected one of {supported_flows}"
            )

        self.callback_url = callback_url
        try:
            self.callback_port = int(callback_port)
        except ValueError as ex:
            raise ValueError(f"Invalid value for callback_port: {ex}")

        self._cache_lock = Lock()
        self._cached_access_token = None
        self._cached_refresh_token = None
        self._cache_expires_at = None

        try:
            self.browser_auto_open = self.to_bool(browser_auto_open)
        except ValueError as ex:
            raise ValueError(f"Invalid value for browser_auto_open: {ex}")

    def new_authenticator(self, _):
        """
        Creates and returns an appropriate authenticator based on the available credentials.
        If username and password are provided, it uses PlainTextAuthenticator to allow legacy
        plain-text authentication. Otherwise, it uses OIDC authentication with OIDCAuthenticator.

        Returns:
            Authenticator: Either a PlainTextAuthenticator or OIDCAuthenticator instance

        Raises:
            Exception: If only one of username/password is provided but not both
        """
        if self.issuer_url is None or self.username is not None or self.password is not None:
            log.debug("Opening connection using default text-based authentication")
            return PlainTextAuthenticator(self.username, self.password)

        log.debug("Opening connection OIDC authentication")
        access_token = self._get_access_token()
        return OIDCAuthenticator(access_token)

    def _get_access_token(self):
        """
        Retrieves an OIDC access token, either using a cached token or fetching a new one.

        Tokens are cached for a specified duration to prevent unnecessary authentication
        calls to the OIDC provider and printing duplicated errors when a session is first started.
        For example, `cqlsh` opens 2 connections. For all those connections the same cached token
        is used. The default cache duration is 60 seconds.
        Method is thread-safe to ensure we don't fetch multiple tokens at the same time when
        opening multiple connections in a connection pool.

        Returns:
            str: A valid OAuth access token to use for authentication.
        """
        with self._cache_lock:
            if self._cached_access_token is not None and time.time() < self._cache_expires_at:
                return self._cached_access_token

            if self.truststore_file:
                if os.path.exists(self.truststore_file) and os.access(
                    self.truststore_file, os.R_OK
                ):
                    log.debug(f"Using custom CA file: {self.truststore_file}")
                    self._ssl_context.load_verify_locations(cafile=self.truststore_file)
                else:
                    log.warning(f"Skipping unreadable truststore file '{self.truststore_file}'")

            # Disable SSL verification if requested (not recommended for production)
            if not self.ssl_verify:
                log.warning("SSL certificate verification is disabled - this is insecure")
                self._ssl_context.check_hostname = False
                self._ssl_context.verify_mode = ssl.CERT_NONE

            self._cached_access_token, self._cached_refresh_token, expires_in = (
                self._fetch_access_token()
            )

            if expires_in is None:
                self._cache_expires_at = time.time() + self.DEFAULT_EXPIRATION_TIME
            else:
                self._cache_expires_at = time.time() + int(expires_in * self.REFRESH_FACTOR)

            log.debug("Access token acquired: %s", self._cached_access_token)
            return self._cached_access_token

    def _fetch_access_token(self):
        try:
            if self.auth_flow == OIDCAuthFlows.CODE:
                if self._cached_refresh_token is None:
                    return self._fetch_authentication_code_flow_access_token()
                else:
                    return self._fetch_authentication_code_flow_access_token_refresh()
            elif self.auth_flow == OIDCAuthFlows.CLIENT:
                return self._fetch_client_credentials_flow_access_token()
            else:
                raise ValueError(f"Unsupported auth flow: {self.auth_flow.value}")
        except Exception as e:
            raise Exception(f"OIDC authentication error: {str(e)}")

    def _fetch_client_credentials_flow_access_token(self):
        """
        Implements OAuth 2.0 Client Credentials flow for machine-to-machine authentication.

        This method performs the following steps:
        1. Discovers the OIDC endpoints using the standard .well-known configuration
        2. Extracts the token endpoint from the discovered configuration
        3. Requests an access token using the client credentials grant type
        4. Extracts and returns the access token from the response

        The method uses client credentials flow with the configured client_id and
        client_secret to authenticate with the OIDC provider.
        Returns:
            tuple: A tuple containing:
                - access_token (str): The new access token
                - refresh_token (str): Always None for client credentials flow
                - expires_in (int): The token expiration in seconds

        Raises:
            Exception: If token discovery or acquisition fails for any reason.
        """
        oidc_config = self._discover_oidc_config(["token_endpoint"])
        token_endpoint = oidc_config.get("token_endpoint")

        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        payload = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        status_code, response_data = self._http_request(
            token_endpoint, method="POST", data=payload, headers=headers
        )

        if status_code != 200:
            raise Exception(f"Failed to obtain access token: HTTP {status_code}")

        try:
            token_data = json.loads(response_data)
        except json.JSONDecodeError:
            raise Exception("Failed to parse OIDC provider response")

        access_token = token_data.get("access_token")
        if not access_token:
            raise Exception("No access token found in the response")

        expires_in = token_data.get("expires_in", None)

        return access_token, None, expires_in

    def _fetch_authentication_code_flow_access_token(self):
        """
        Implements OAuth 2.0 Authorization Code flow with PKCE for interactive authentication.

        This method performs the following steps:
        1. Discovers OIDC endpoints using the standard .well-known configuration
        2. Generates PKCE code challenge and verifier
        3. Constructs authorization URL and prints it for user interaction
        4. Starts a local HTTP server to receive the authorization callback
        5. Exchanges the authorization code for an access token

        Returns:
            tuple: A tuple containing:
                - access_token (str): The new access token
                - refresh_token (str): The new refresh token (if provided)
                - expires_in (int): The token expiration in seconds

        Raises:
            Exception: If any step of the authorization code flow fails.
        """
        oidc_config = self._discover_oidc_config(["authorization_endpoint", "token_endpoint"])
        authorization_endpoint = oidc_config.get("authorization_endpoint")
        token_endpoint = oidc_config.get("token_endpoint")

        code_verifier, code_challenge, state = self._generate_security_params()

        # Set up callback server to get actual port
        authorization_code = None
        received_state = None
        server_error = None
        callback_url = self.callback_url

        class CallbackHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                nonlocal authorization_code, received_state, server_error

                html_error = (
                    "<html>"
                    "  <body>"
                    "    <h1>Authentication Error</h1>"
                    "    <p>%s. You can close this window.</p>"
                    "  </body>"
                    "</html>"
                )
                html_ok = (
                    "<html>"
                    "  <body>"
                    "    <h1>Authentication Successful</h1>"
                    "    <p>You can close this window and return to your application.</p>"
                    "  </body>"
                    "</html>"
                )

                try:
                    parsed_url = urllib.parse.urlparse(self.path)
                    query_params = urllib.parse.parse_qs(parsed_url.query)

                    if parsed_url.path == callback_url:
                        if "error" in query_params:
                            server_error = f"Authorization error: {query_params['error'][0]}"

                            self.send_response(400)
                            self.send_header("Content-type", "text/html")
                            self.end_headers()
                            html = html_error % "An error occurred during authentication"
                            self.wfile.write(html.encode("utf-8"))
                            return

                        received_state = query_params.get("state", [None])[0]
                        authorization_code = query_params.get("code", [None])[0]

                        if not authorization_code:
                            server_error = "No authorization code received"
                            self.send_response(400)
                            self.send_header("Content-type", "text/html")
                            self.end_headers()
                            html = html_error % "No authorization code received"
                            self.wfile.write(html.encode("utf-8"))
                            return

                        # Send success response
                        self.send_response(200)
                        self.send_header("Content-type", "text/html")
                        self.end_headers()
                        self.wfile.write(html_ok.encode("utf-8"))
                    else:
                        self.send_response(404)
                        self.end_headers()
                except Exception as e:
                    server_error = f"Callback handler error: {str(e)}"
                    self.send_response(500)
                    self.end_headers()

            def log_message(self, format, *args):
                # Suppress server logs
                pass

        # Start the callback server with socket reuse enabled which might be
        # needed when using a fixed port.
        class ReuseAddrTCPServer(socketserver.TCPServer):
            allow_reuse_address = True

        with ReuseAddrTCPServer(("", self.callback_port), CallbackHandler) as httpd:
            actual_port = httpd.server_address[1]
            redirect_uri = f"http://127.0.0.1:{actual_port}{self.callback_url}"

            # Build authorization URL
            auth_params = {
                "response_type": "code",
                "client_id": self.client_id,
                "redirect_uri": redirect_uri,
                "scope": "openid",
                "state": state,
                "code_challenge": code_challenge,
                "code_challenge_method": "S256",
            }

            auth_url = f"{authorization_endpoint}?{urllib.parse.urlencode(auth_params)}"

            if self.browser_auto_open:
                # Print the authorization URL for the user
                print(
                    "\n"
                    "Attempting to automatically open the authorization page in your "
                    "default web browser."
                    "\n"
                    "If it does not open, please manually open the following URL:"
                )
                webbrowser.open(auth_url)
            else:
                print("\nPlease open the following URL in your browser to authenticate:")

            print(f"\n{auth_url}")
            print(f"\nWaiting for callback on {redirect_uri}...")

            try:
                # Handle requests in a separate thread so we can timeout
                server_thread = threading.Thread(target=httpd.serve_forever)
                server_thread.daemon = True
                server_thread.start()

                # Wait for callback with timeout
                timeout_seconds = 300  # 5 minutes
                start_time = time.time()

                while authorization_code is None and server_error is None:
                    if time.time() - start_time > timeout_seconds:
                        raise Exception("Timeout waiting for authentication callback")
                    time.sleep(0.1)

            finally:
                httpd.shutdown()
                server_thread.join()

        if server_error:
            raise Exception(f"Server error {server_error}")

        if received_state != state:
            raise Exception("Invalid state parameter - possible CSRF attack")

        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        token_payload = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "code": authorization_code,
            "redirect_uri": redirect_uri,
            "code_verifier": code_verifier,
        }

        if self.client_secret:
            token_payload["client_secret"] = self.client_secret

        status_code, response_data = self._http_request(
            token_endpoint, method="POST", data=token_payload, headers=headers
        )

        if status_code != 200:
            raise Exception(f"Failed to exchange authorization code for token: HTTP {status_code}")

        try:
            token_data = json.loads(response_data)
        except json.JSONDecodeError:
            raise Exception("Failed to parse OIDC provider response")

        access_token = token_data.get("access_token")

        if not access_token:
            raise Exception("No access token found in token response")

        print("Authentication successful!")

        refresh_token = token_data.get("refresh_token", None)
        expires_in = token_data.get("expires_in", None)

        return access_token, refresh_token, expires_in

    def _fetch_authentication_code_flow_access_token_refresh(self):
        """
        Refreshes an OIDC access token using a cached refresh token.

        Returns:
            tuple: A tuple containing:
                - access_token (str): The new access token
                - refresh_token (str): The new refresh token (if provided)
                - expires_in (int): The token expiration in seconds

        Raises:
            Exception: If the token refresh fails
        """
        # Discover OIDC endpoints
        oidc_config = self._discover_oidc_config(required_fields=["token_endpoint"])
        token_endpoint = oidc_config["token_endpoint"]

        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        token_payload = {
            "grant_type": "refresh_token",
            "refresh_token": self._cached_refresh_token,
            "client_id": self.client_id,
        }

        if self.client_secret:
            token_payload["client_secret"] = self.client_secret

        status_code, response_data = self._http_request(
            token_endpoint, method="POST", data=token_payload, headers=headers
        )

        if status_code != 200:
            raise Exception(f"Failed to refresh access token: HTTP {status_code}")

        try:
            token_data = json.loads(response_data)
        except json.JSONDecodeError:
            raise Exception("Failed to parse OIDC provider response")

        access_token = token_data.get("access_token")

        if not access_token:
            raise Exception("No access token found in token response")

        # Use new refresh token if provided, otherwise keep the existing one
        refresh_token = token_data.get("refresh_token", self._cached_refresh_token)

        expires_in = token_data.get("expires_in", None)

        return access_token, refresh_token, expires_in

    def _discover_oidc_config(self, required_fields=[]):
        """
        Discovers OIDC endpoints by fetching the .well-known/openid-configuration document.

        Args:
            required_fields (list[str]): List of field names that must be present
                                       in the OIDC configuration. Defaults to empty list.

        Returns:
            dict: A dictionary containing the OIDC endpoints (authorization_endpoint,
                  token_endpoint, etc.)

        Raises:
            Exception: If the discovery fails, if the JSON parsing fails, or if any
                      required fields are missing from the configuration.
        """
        well_known_url = f"{self.issuer_url}/.well-known/openid-configuration"
        status_code, response_data = self._http_request(well_known_url)

        if status_code != 200:
            raise Exception(f"Failed to discover OIDC configuration: HTTP {status_code}")

        try:
            oidc_config = json.loads(response_data)
        except json.JSONDecodeError:
            raise Exception("Failed to parse OIDC configuration response")

        for field in required_fields:
            if field not in oidc_config or not oidc_config[field]:
                raise Exception(f"Missing '{field}' in OIDC configuration from {well_known_url}")

        return oidc_config

    def _generate_security_params(self):
        """
        Generates security parameters for the OIDC authentication flow.

        This method generates a code verifier and code challenge for PKCE, which are used
        to secure the authorization code flow. It also generates a state parameter to prevent
        CSRF attacks.

        Returns:
            tuple: A tuple containing
                - code_verifier (str): A securely generated code verifier
                - code_challenge (str): The SHA-256 hash of the code verifier, base64 URL-encoded
                - state (str): A securely generated state parameter to prevent CSRF attacks
        """
        code_verifier = (
            base64.urlsafe_b64encode(secrets.token_bytes(32)).decode("utf-8").rstrip("=")
        )
        code_challenge = (
            base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode("utf-8")).digest())
            .decode("utf-8")
            .rstrip("=")
        )
        state = secrets.token_urlsafe(32)

        return code_verifier, code_challenge, state

    def _http_request(self, url, method="GET", data=None, headers=None, max_retries=3):
        """
        Makes an HTTP request to the specified URL using Python's standard library with retry logic.

        This helper method handles both GET and POST requests to OIDC endpoints with automatic
        retry for transient failures. Python's standard library is used intentionally to avoid
        adding external dependencies like 'requests', which would require additional libraries
        when adding this package in HCD.

        Supports custom certificate authority (CA) files for SSL verification
        when connecting to OIDC providers that use certificates not in the
        system's default trust store.

        Args:
            url (str): The URL to send the request to
            method (str, optional): HTTP method to use. Defaults to "GET".
            data (dict or bytes, optional): Data to send in the request body.
                If a dict is provided, it will be URL-encoded automatically.
            headers (dict, optional): HTTP headers to include in the request.
                Defaults to an empty dict.
            max_retries (int, optional): Maximum number of retry attempts for transient failures.
                Defaults to 3.

        Returns:
            tuple: A tuple containing (status_code, response_body_text)

        Raises:
            Exception: For connection errors after all retries are exhausted, or for
                      non-retryable errors like SSL certificate issues.
        """
        if headers is None:
            headers = {}

        if isinstance(data, dict):
            data = urllib.parse.urlencode(data).encode("utf-8")

        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        for attempt in range(max_retries + 1):
            try:
                with urllib.request.urlopen(req, context=self._ssl_context) as response:
                    response_data = response.read().decode("utf-8")
                    return response.getcode(), response_data
            except urllib.error.HTTPError as e:
                # Don't retry HTTP errors - they're usually not transient
                return e.code, e.read().decode("utf-8")
            except (urllib.error.URLError, socket.timeout) as e:
                if attempt == max_retries:
                    # All retries exhausted, raise the final exception
                    if isinstance(e, urllib.error.URLError):
                        raise Exception(
                            f"Connection error after {max_retries + 1} attempts: {str(e.reason)}"
                        )
                    else:
                        raise Exception(f"Request timeout after {max_retries + 1} attempts")

                # Calculate wait time with exponential backoff
                wait_time = 0.5 * (2**attempt)
                log.debug(
                    f"Request failed (attempt {attempt + 1}/{max_retries + 1}), "
                    f"retrying in {wait_time}s: {str(e)}"
                )
                time.sleep(wait_time)
            except ssl.SSLError as e:
                # SSL errors are usually not transient, don't retry
                raise Exception(
                    f"SSL error: {str(e)}."
                    " Consider providing a valid truststore file or set ssl_verify=False."
                )

    @staticmethod
    def to_bool(value):
        """
        Convert a string to a boolean value, case-insensitive.

        Args:
            value: The value to convert. Can be a string, boolean, or None.

        Returns:
            bool: True if value is True, 'true', 'yes', 'y', '1' (case-insensitive).
                  False if value is False, 'false', 'no', 'n', '0' (case-insensitive).

        Raises:
            ValueError: If the value cannot be converted to a boolean.
        """
        if isinstance(value, bool):
            return value
        if value is None:
            return False
        if isinstance(value, str):
            value = value.lower().strip()
            if value in ("true", "yes", "y", "1"):
                return True
            if value in ("false", "no", "n", "0"):
                return False

        raise ValueError(f"Cannot convert {value} to boolean")


class OIDCAuthProvider(AuthProvider):
    """
    An :class:`~.AuthProvider` that works with DataStax Enterprise (DSE) and DataStax
    Hyper-Converged Database (HCD) to authenticate using OIDC (OAuth 2.0).

    This auth provider is meant to be used with the DataStax Python driver directly, assuming
    that OIDC authentication is responsibility of the application using the driver.

    Example usage::

        from cassandra.cluster import Cluster
        from datastax_db_auth.auth import OIDCAuthProvider

        auth_provider = OIDCAuthProvider(access_token='your_access_token')
        cluster = Cluster(auth_provider=auth_provider)

    """

    def __init__(self, access_token):
        self.access_token = access_token

    def new_authenticator(self, _):
        return OIDCAuthenticator(self.access_token)


class OIDCAuthenticator(Authenticator):
    """
    An :class:`~.Authenticator` that works with DataStax Enterprise 6.9 (DSE) or DataStax
    Hyper-Converged Database (HCD) to authenticate using OIDC (OAuth 2.0).
    """

    def __init__(self, access_token):
        self.access_token = access_token

    def initial_response(self):
        if self.server_authenticator_class == "com.datastax.bdp.cassandra.auth.DseAuthenticator":
            return "OAUTHBEARER".encode()
        else:
            raise Exception(
                "Unsupported server authenticator class: %s" % self.server_authenticator_class
            )

    def evaluate_challenge(self, challenge):
        if challenge == "OAUTHBEARER-START".encode():
            return self.access_token.encode()
        else:
            raise Exception("Did not receive a valid challenge response from server")
